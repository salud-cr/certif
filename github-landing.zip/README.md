# Landing estática (GitHub Pages)
Sitio 100% estático listo para publicar en **GitHub Pages**.

## Publicar
1. Crea un repo en GitHub (p.ej. `landing` o `tuusuario.github.io`).
2. Sube estos archivos (o haz commit con Git).
3. Ve a **Settings → Pages → Build and deployment**.
4. En **Source**, elige **Deploy from a branch**.
5. **Branch:** `main` y **Folder:** `/ (root)` → **Save**.
6. Abre la URL que GitHub te muestra (p.ej. `https://tuusuario.github.io/landing/`).

> Si usas `tuusuario.github.io` como nombre del repo, tu sitio saldrá en la raíz: `https://tuusuario.github.io/`.